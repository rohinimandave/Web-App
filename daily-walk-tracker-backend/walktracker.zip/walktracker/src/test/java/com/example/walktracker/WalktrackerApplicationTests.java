package com.example.walktracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalktrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
